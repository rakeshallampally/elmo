#ifndef NEOOMNIDRIVEERRORS_INCLUDEDEF_H
#define NEOOMNIDRIVEERRORS_INCLUDEDEF_H


/*
 * struct which stores all the errors 
 */

struct DriveErrors
{
  int iNoError=0;                                     // No error             
  int iInitPosNotSet=1;                               // Intitial positon is not set                     
  int iStatusReqFail=2;                               // No answer on status request
  int iMotorFailure=3;                                // Motor failure lathced
  int iOverHeating=4;                                 // Over heating
  int iShortCircuit=5;                                // Drive error short cirucit
  int iOverVoltage=6;                                 // Drive error over voltage 
  int iUnderVoltage=7;                                // Drive error under voltage
  int iMotorOff=8;                                    // Motor is still Off
  int iCurrentLimintOn=9;                             // Motor current limit on
  int iFeedbackLoss=10;                               // feedback loss
  int iPeakCurrentExced=11;                           // Peak current excced
  int iSpeedTrack=12;                                 // Speed track error
  int iPositionTrack=13;                              // position track error
  int iSpeedLimit=14;                                 // speed limit exceeded
  int iMotorStuck=15;                                 // motor stuck

};


//declaring objects for the motor params struct
DriveErrors m_DriveError;


#endif
