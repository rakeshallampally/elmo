
#include <neo_kinematics_omnidrive/DriveModule.h>
#include <unistd.h>
#include <neo_kinematics_omnidrive/ElmoMotorCtrl.h>
using namespace std;

DriveModule::DriveModule()
{
  Steer=new ElmoMotorCtrl();
  Drive=new ElmoMotorCtrl();

}

DriveModule::~DriveModule()
{
 
}


int DriveModule::sendNetStartCanOpen()
{ 
  Drive->sendCanMessage(0, 2, 1);
  usleep(100000);
  return 0;
}

int DriveModule::init(
                       int TxPDO1_WSteer, int TxPDO2_WSteer, int RxPDO2_WSteer, int TxSDO_WSteer, int RxSDO_WSteer, int  Steer_iEncIncrPerRevMot, double Steer_dVelMeasFrqHz,
                       double Steer_dGearRatio, double Steer_dBeltRatio, int  Steer_iSign, double Steer_dVelMaxEncIncrS, double  Steer_dAccIncrS2, double Steer_dDecIncrS2,
                       int Steer_iEncOffsetIncr, bool Steer_bIsSteer, double  Steer_dCurrentToTorque, double  Steer_dCurrMax, int  Steer_iHomingDigIn,int Steer_iHomingTimeout,int Steer_iModulo, 
                       int TxPDO1_WDrive, int TxPDO2_WDrive, int RxPDO2_WDrive, int TxSDO_WDrive, int RxSDO_WDrive, int  Drive_iEncIncrPerRevMot, double Drive_dVelMeasFrqHz,
                       double Drive_dGearRatio, double Drive_dBeltRatio, int  Drive_iSign, double Drive_dVelMaxEncIncrS, double  Drive_dAccIncrS2, double Drive_dDecIncrS2,
                       int Drive_iEncOffsetIncr, bool Drive_bIsSteer, double  Drive_dCurrentToTorque, double  Drive_dCurrMax, int  Drive_iHomingDigIn,int Drive_iHomingTimeout,int Drive_iModulo 
                     )
{
  int iDriveRet = 0;                   //variable to store return value of Drive initializing motor
  int iSteerRet = 0;                   //variable to store return value of Steer initializing motor
  int iDriveMotorOn=0;                 //variable to store return value of Drive motor turn on 
  int iSteerMotorOn=0;                 //variable to store return value of Steer motor turn on 
  
 

//setting params of Drivemotor in driveparams class
  m_drive1Param.settingParams
  (
      0,
      Drive_iEncIncrPerRevMot,
      Drive_dVelMeasFrqHz,
      Drive_dBeltRatio,
      Drive_dGearRatio,
      Drive_iSign,
      Drive_dVelMaxEncIncrS,
      Drive_dAccIncrS2,
      Drive_dDecIncrS2,
      Drive_iEncOffsetIncr,
      Drive_bIsSteer,
      Drive_dCurrentToTorque,
      Drive_dCurrMax,
      Drive_iHomingDigIn,
      Drive_iHomingTimeout,
      Drive_iModulo

  );
  


  //setting params of steermotor in driveparams class

  m_steer1Param.settingParams
  (   1,
      Steer_iEncIncrPerRevMot,
      Steer_dVelMeasFrqHz,
      Steer_dGearRatio,
      Steer_dBeltRatio,
      Steer_iSign,
      Steer_dVelMaxEncIncrS,
      Steer_dAccIncrS2,
      Steer_dDecIncrS2,
      Steer_iEncOffsetIncr,
      Steer_bIsSteer,
      Steer_dCurrentToTorque,
      Steer_dCurrMax,
      Steer_iHomingDigIn,
      Steer_iHomingTimeout,
      Steer_iModulo

  );


  //setting the Drive motor canoopen params
  Drive->setCanOpenParam(TxPDO1_WDrive,TxPDO2_WDrive,RxPDO2_WDrive,TxSDO_WDrive,RxSDO_WDrive);

  //setting the Steer motor params
  Drive->settingDriveParams(m_drive1Param);

  //setting the steer motor canopoen params
  Steer->setCanOpenParam(TxPDO1_WSteer,TxPDO2_WSteer,RxPDO2_WSteer,TxSDO_WSteer,RxSDO_WSteer);

  //setting the steer motor params 
  Steer->settingDriveParams(m_steer1Param);
  


  usleep(100000);
  
  //checking if there is any error with drive motor initialization so that program can terminate
  if((iDriveRet = Drive->initMotorCtrl())>0)
  {
     return iDriveRet;
  }

  //checking if there is any error with Steer motor initialization so that program can terminate
  if((iSteerRet = Steer->initMotorCtrl())>0)
  {
    return iSteerRet;
  }
  

  // turn on Drive motor only when drive motor is initialized successufully
  if(iDriveRet==0)
  {

    iDriveMotorOn=Drive->turnOnMotor();
    if(iDriveMotorOn>0)
    {
      return iDriveMotorOn;
    }  
  }

  // turn on Steer motor only when Steer motor is initialized successufully
  if(iSteerRet==0)
  {
    iSteerMotorOn=Steer->turnOnMotor();
    if(iSteerMotorOn>0)
    {

      return iSteerMotorOn;
    }  
  }
  
 Drive->turnOffMotor();
 Steer->turnOffMotor();

  return 0;
}

int DriveModule::motorHoming()
{
  int iRet;      //return variable which stores executeHoming funciton return value

 //execute homing for the steer motor 
 iRet=Steer->executeHoming();

 return iRet;

}

void DriveModule::setVelInRadS(double dGearvelrads)
{

 //setting veloicty of motor in rads 
 Drive->setVelInRadS(dGearvelrads);
 Steer->setVelInRadS(dGearvelrads);
 
}


void DriveModule::getGearPosAndVel(int i,double *pdPosGearRad, double *pdVelGearRadS)
{
  *pdPosGearRad=0;
  *pdVelGearRadS=0;
  
  // for i=0, it gets pos and vel for Drive motor
  if(i==0) 
  {
  Drive->getGearPosAndVel(pdPosGearRad, pdVelGearRadS);
  }

  // for i=1, it gets pos and vel for Steer motor
  if (i==1)
  {
  Steer->getGearPosAndVel(pdPosGearRad, pdVelGearRadS);
  }
}


void DriveModule::recMessages()
{
  Drive->evaluatingMessageReceived();
  Steer->evaluatingMessageReceived();
}