
#include <neo_kinematics_omnidrive/ElmoMotorCtrl.h>
#include <unistd.h>
#include <neo_kinematics_omnidrive/SocketCan.h>
using namespace std;

ElmoMotorCtrl::ElmoMotorCtrl()
{
  m_dPositonGearMeasInRad=0;     //Gear positin measurement in radians
  m_dVelGearMeasInRadS=0;        //Gear velocity measurement in rad/s      
  m_iStatus=0;
  m_sCanCtrl=new SocketCan();
}

ElmoMotorCtrl::~ElmoMotorCtrl()
{
}

void ElmoMotorCtrl::setCanOpenParam( int iTxPDO1, int iTxPDO2, int iRxPDO2, int iTxSDO, int iRxSDO)
{
  m_ParamCanopen.iTxPDO1 = iTxPDO1;
	m_ParamCanopen.iTxPDO2 = iTxPDO2;
	m_ParamCanopen.iRxPDO2 = iRxPDO2;
	m_ParamCanopen.iTxSDO = iTxSDO;
	m_ParamCanopen.iRxSDO = iRxSDO;

}



int ElmoMotorCtrl::initMotorCtrl()
{
  int iPositionCnt;                                     // posiotion
  bool bPosNotSet=true;                                 // boolean for position is not set
  int iMaxAcc = int(m_DriveParameter.getMaxAccln());    // max accln
  int iMaxDcc = int(m_DriveParameter.getMaxDecln());    // max decln
  int iCount;                                           // counter
  CanMesg Msg;                                          // object for can message  

  //turn of motor
  setInterpreter(8, 'M', 'O', 0, 0);
  usleep(20000);
  setInterpreter(8, 'X', 'M', 2,m_DriveParameter.getModulo());
  usleep(20000);
  setInterpreter(8, 'X', 'M', 1, -m_DriveParameter.getModulo());
  usleep(20000);

  //setting velocity as motion control( so as per manual following commands should be performed pg-77)
  setInterpreter(8, 'M', 'O', 0, 0);

  //switch to unit mode 2
  setInterpreter(8, 'U', 'M', 0, 2);
  // switch to profile mode 1(if unit mode 2)
  setInterpreter(8, 'P', 'M', 0, 1);

  // set maximum Acceleration to X Incr/s^2
  setInterpreter(8, 'A', 'C', 0, iMaxAcc);
  // set maximum decceleration to X Incr/s^2
  setInterpreter(8, 'D', 'C', 0, iMaxDcc);
  usleep(10000);

  //set position encounter to zero
  setInterpreter(8, 'P', 'X', 0, 0);
  usleep(100000);

  iCount=0;
  do
  {    
    m_sCanCtrl->receiveMsg(&Msg);
    if(Msg.getByte(0)=='P' && Msg.getByte(1)=='X')
    {
      iPositionCnt=(Msg.getByte(4))|(Msg.getByte(5)<<8)|(Msg.getByte(6)<<16)|(Msg.getByte(7)<<24);
      m_dPositonGearMeasInRad=m_DriveParameter.getmotion_direction()*m_DriveParameter.convertPosMotIncrToPosGearRad(iPositionCnt);
      bPosNotSet=false;
    }
    if (iCount>300)
    {

     bPosNotSet=false;
      return 1;      // Intitial positon is not set
    } 
    iCount++;
    usleep(10000);

  }while (bPosNotSet==true);


  // ---------- set PDO mapping
  //PDO mapping is done for only TPDO, bcz it enables the drive to send a predefined messsage in response to an event,if it is not confiugred the drives doesnt transmit positon for TPDO1
  // Mapping of TPDO1:
  // - position
  // - velocity
  // stop all emissions of TPDO1(in pg  5-6  in elmo implementation guide)
  sendingSDODownload(0x1A00, 0, 0);

  // position 4 byte of TPDO1
  sendingSDODownload(0x1A00, 1, 0x60640020);

  // velocity 4 byte of TPDO1
  sendingSDODownload(0x1A00, 2, 0x60690020);

  // transmission type "synch"
  sendingSDODownload(0x1800, 2, 1);

  // activate mapped objects
  sendingSDODownload(0x1A00, 0, 2);
  return 0;
}

int ElmoMotorCtrl::configureHoming()
{

  double dHomeVelInRads=-0.5;
  const int c_iPosReference = m_DriveParameter.getEncoderOffset();

  // wait at least 0.5 sec.
  //usleep(500000);

  //disarm homing
  setInterpreter(8, 'H', 'M', 1, 0);
  //waiting for some time so that controller gets time to understand the command 
  //usleep(20000);
  
  //configure homing sequences
  // setting the value sucht that increment counter resets after the homingevent occurs
  setInterpreter(8, 'H', 'M', 2,c_iPosReference);
  //usleep(20000);

  //choosing channel/switch on which controller has to listen for change of homing event(high/low/falling/rising)
  setInterpreter(8, 'H', 'M', 3,m_DriveParameter.getHomDigIn());
  //usleep(20000);

  //choosing the action the controller should perform afer the homing event occurs
  // HM[4]=2 :do nothing  
  setInterpreter(8, 'H', 'M', 4,2);
  //usleep(20000);

  //setting the absolute setting of postion counter {(HM[5]=0) == HM[2]} after the homing event
  setInterpreter(8, 'H', 'M',5,0);
  //usleep(20000);

  //turning the motor
  setVelInRadS(dHomeVelInRads);
  

  return 0;
}


void ElmoMotorCtrl::armHoming()
{
  CanMesg Msg;
  bool bMsgRecvd =true;
   // wait at least 0.5 sec.
  usleep(500000);
  //clear the can buffer and get rid of all uneccessary messages
  do
  {
    bMsgRecvd = m_sCanCtrl->receiveMsg(&Msg);
  }
  while(bMsgRecvd == true);

  //arm homing
  setInterpreter(8, 'H', 'M', 1, 1);
}

int ElmoMotorCtrl::homingDone()
{
  m_bHomingStatus=false;
  bool bStatusDisarm=false;   //boolean variable to store the status of homing
  setInterpreter(4, 'H', 'M', 1, 0);
  evaluatingMessageReceived();

  bStatusDisarm=getStatusOfHoming();

  if(bStatusDisarm==true)
  {
    setVelInRadS(0);
    //usleep(500000);
    return 0;
  }

  //usleep(20000);
  return 17;           //status not yet homed              
  
}



int ElmoMotorCtrl::turnOnMotor()
{
  CanMesg Msg;
  int iCount;
  int iStatus; 
  int iReturn;
  bool bNoStatusReq=true;
  bool bRet=true;

  //turning on the motor
  setInterpreter(8,'M','O',0,1);
  usleep(25000);

  //clearing the can buffer
  do
  {
    bRet = m_sCanCtrl->receiveMsg(&Msg);
  }
  while(bRet == true);

  //sending request to evaluate status
  setInterpreter(4,'S','R',0,0);
  iCount=0;
  do
  {
    m_sCanCtrl->receiveMsg(&Msg);
    if(Msg.getByte(0)=='S' && Msg.getByte(1)=='R')
    {
      iStatus=(Msg.getByte(4))|(Msg.getByte(5)<<8)|(Msg.getByte(6)<<16)|(Msg.getByte(7)<<24);
      iReturn = evaluateStatusRegister(iStatus);
      return iReturn;
      bNoStatusReq=false;
    }
    if(iCount>300)
    {
      return 3;        // No answer on status request
      bNoStatusReq=false;
    }

    usleep(10000);
    iCount++;
  }while(bNoStatusReq==true);

  return 0;
}



bool ElmoMotorCtrl::turnOffMotor()
{
  bool bRet = true;
  setInterpreter(8,'M','O',0,0);
  usleep(20000);
  return bRet;
}







void ElmoMotorCtrl::setVelInRadS(double dGearvelrads)
{
  int iVelEncIncrement;
  //calculating motor velocit from joint velocity
  iVelEncIncrement=m_DriveParameter.getmotion_direction()*m_DriveParameter.convertVelGearRadSToVelMotIncrPeriod(dGearvelrads);

  if(iVelEncIncrement>m_DriveParameter.getMaxVel())
  {
    iVelEncIncrement=(int)m_DriveParameter.getMaxVel();
  }
  else if(iVelEncIncrement<-m_DriveParameter.getMaxVel())
  {
    iVelEncIncrement=-(int)m_DriveParameter.getMaxVel();
  }
  
  //we can configure jog velocity after setting um=2,pm=1 and ac,dc
  setInterpreter(8,'J','V',0,iVelEncIncrement);
  
  //after settomg jog velocity we have to use the begin motion command to run the motor
  setInterpreter(4,'B','G',0,0);

  //sending sync message to trigger devices for sending data
  sendCanMessage(0x80, 0, 0);


}


void ElmoMotorCtrl::stopMotion()
{
  CanMesg Msg;
  bool bRet=true;
  do
  {
    bRet = m_sCanCtrl->receiveMsg(&Msg);
  }
  while(bRet == true);
  //To stop the motion of motor
  setInterpreter(4,'S','T',0,0);

  usleep(2500);
  
  //sending sync message to trigger devices for sending data
  sendCanMessage(0x80, 0, 0);
}

int ElmoMotorCtrl::evaluateStatusRegister(int iStatus)
{
 
  if(isBitSet(iStatus,6))
  {
     // requesting the detailed description of motor failure
     setInterpreter(4,'M','F',0,0);
     return 4;       // Motor failure lathced
  }

  else if(isBitSet(iStatus,0))
  {
    if((0x0000000E & iStatus)==12)
      return 5;   // Over heating

    if((0x0000000E&iStatus)==10)
      return 6;    // Drive error short cirucit

    if((0x0000000E&iStatus)==4)
      return 7;     // Drive error over voltage 
      
    if((0x0000000E&iStatus)==2)
      return 8;     // Drive error under voltage

    setInterpreter(4,'M','F',0,0);  
  }

  else
  {
    if(isBitSet(iStatus,4))
    {    
        return 0;
    }   

    else
    {   
        return 9;    // Motor is still Off
    }

    if(isBitSet(iStatus,13))
    {
       return 10;    // Motor current limit on
    }
  }
  return 0;
}




int ElmoMotorCtrl::evaluatingMessageReceived()
{
  CanMesg Msg;
  int iDigIn;
  int iFailure;
  bool bRet=true;
  int iPosIncrPeriod;   //encoder increments per measurment period for positon
  int iVelIncrPeriod;     //encoder increments per measurement period for velocity


    //sending sync message to trigger devices for sending data
  sendCanMessage(0x80, 0, 0); 

  do
  {
    
    bRet=m_sCanCtrl->receiveMsg(&Msg);
    //----------------------------------------------------------------------------------------------------------------------------------
    //evalutaing from binary interpreter
    if(Msg.m_iId==m_ParamCanopen.iTxPDO2)
    {
      // user mode
      if( (Msg.getByte(0) == 'U') && (Msg.getByte(1) == 'M') ) 
      {
        iDigIn = 0x1FFFFF & ( (Msg.getByte(7) << 24) | (Msg.getByte(6) << 16)| (Msg.getByte(5) << 8) | (Msg.getByte(4)) );
      }
      // status register
      else if( (Msg.getByte(0) == 'S') && (Msg.getByte(1) == 'R') ) 
      {
        m_iStatus = (Msg.getByte(7) << 24) | (Msg.getByte(6) << 16)| (Msg.getByte(5) << 8) | (Msg.getByte(4) );
        evaluateStatusRegister(m_iStatus);
      }
      // motor failure
      else if( (Msg.getByte(0) == 'M') && (Msg.getByte(1) == 'F') ) 
      {
        iFailure = (Msg.getByte(7) << 24) | (Msg.getByte(6) << 16)| (Msg.getByte(5) << 8) | (Msg.getByte(4) );
        if( isBitSet(iFailure, 2) )
        {
          return 11;          // feedback loss
        }

        if( isBitSet(iFailure, 3) )
        {
          return 12;         // Peak current excced
        }

        if( isBitSet(iFailure, 7) )
        {
          return 13;        // Speed track error
        }

        if( isBitSet(iFailure, 8) )
        {
          return 14;       // position track error
        }

        if( isBitSet(iFailure, 17) )
        {
          return 15;       // speed limit exceeded
        }

        if( isBitSet(iFailure, 21) )
        {
          return 16;       // motor stuck
        }
      }
      else if( (Msg.getByte(0) == 'H') && (Msg.getByte(1) == 'M') )
      {
        // status message (homingDone armed = 1 / disarmed = 0) is encoded in 5th byte
        if(Msg.getByte(4) == 0)
        {
          // if 0 received: elmo disarmed homingDone after receiving the defined event
          m_bHomingStatus = true;
        }
      }

    }

 
    //--------------------------------------------------------------------------------------------------------------------
    // evaluate messages from TPD01 which is transmitted on sync msg
    if(Msg.m_iId==m_ParamCanopen.iTxPDO1)
    {
      iPosIncrPeriod = (Msg.getByte(3) << 24) | (Msg.getByte(2) << 16)| (Msg.getByte(1) << 8) | (Msg.getByte(0) );

      m_dPositonGearMeasInRad=m_DriveParameter.getmotion_direction()* m_DriveParameter.convertPosMotIncrToPosGearRad(iPosIncrPeriod);

      iVelIncrPeriod = (Msg.getByte(7) << 24) | (Msg.getByte(6) << 16)| (Msg.getByte(5) << 8) | (Msg.getByte(4) );

      m_dVelGearMeasInRadS=m_DriveParameter.getmotion_direction() * m_DriveParameter.convertVelMotIncrPeriodToVelGearRadS(iVelIncrPeriod);



    } 

  }while(bRet==true);

  return 0;
}



void ElmoMotorCtrl::getGearPosAndVel(double *pdPositonGearMeasInRad, double *pdVelGearMeasInRadS)
{
  *pdPositonGearMeasInRad = m_dPositonGearMeasInRad;
  *pdVelGearMeasInRadS    = m_dVelGearMeasInRadS;
}


void ElmoMotorCtrl::getGearVel(double *pdVelGearMeasInRadS)
{
  *pdVelGearMeasInRadS  = m_dVelGearMeasInRadS;
}


bool ElmoMotorCtrl::getStatusOfHoming()
{
  return m_bHomingStatus;
}



bool ElmoMotorCtrl::isBitSet(int iValue, int iBit)
{
  if((iValue & (1<<iBit))==0)
    return false;
  else
    return true;
}



void ElmoMotorCtrl::sendingSDODownload(int iIndex, int iSubindex, int iData)
{
  CanMesg msg;
  msg.m_iId=m_ParamCanopen.iRxSDO;
  msg.m_iLen=8;

  const int ciInitDownloadRequest = 0x20;//for bits 5,6,7 of byte 0  should have 001(pg4-2 in implementation guide)
	const int ciByteswithNoData = 0x00; //  for bits 2,3,4 should have 000
	const int ciExpedited = 0x02;//for bit 1 should have 1
	const int ciDataSizeIndicator = 0x01;//for bit 0 shoud have 1

  unsigned char cMesg[8];

  cMesg[0]=ciInitDownloadRequest|ciExpedited|ciDataSizeIndicator|(ciByteswithNoData<<2);
  cMesg[1]=iIndex;
  cMesg[2]=iIndex>>8;
  cMesg[3]=iSubindex;
  cMesg[4]=iData;
  cMesg[5]=iData>>8;
  cMesg[6]=iData>>16;
  cMesg[7]=iData>>24;

  msg.set(cMesg[0],cMesg[1],cMesg[2],cMesg[3],cMesg[4],cMesg[5],cMesg[6],cMesg[7]);
  m_sCanCtrl->transmitMsg(msg);
}







void ElmoMotorCtrl::setInterpreter(int iDatalen,char cmdchar1,char cmdchar2,int iIndex,int iData )
{
  char cIndex[2];
  char cInt[4];
  CanMesg Cmsg;
  Cmsg.m_iId=m_ParamCanopen.iRxPDO2;
  Cmsg.m_iLen=iDatalen;

  cIndex[0]=iIndex;
  cIndex[1]=(iIndex >> 8) & 0x3F;

  cInt[0] = iData;
	cInt[1] = iData >> 8;
	cInt[2] = iData >> 16;
	cInt[3] = iData >> 24;

  Cmsg.set(cmdchar1,cmdchar2,cIndex[0],cIndex[1],cInt[0],cInt[1],cInt[2],cInt[3]);
  m_sCanCtrl->transmitMsg(Cmsg);

}




void ElmoMotorCtrl::sendCanMessage(int iId, int iLen, unsigned char cByte)
{
  CanMesg msg;
  msg.m_iId=iId;
  msg.m_iLen=iLen;
  unsigned char cMesg[8];

  cMesg[0]=cByte;
  cMesg[1]=0;
  cMesg[2]=0;
  cMesg[3]=0;
  cMesg[4]=0;
  cMesg[5]=0;
  cMesg[6]=0;
  cMesg[7]=0;

  msg.set(cMesg[0],cMesg[1],cMesg[2],cMesg[3],cMesg[4],cMesg[5],cMesg[6],cMesg[7]);
  m_sCanCtrl->transmitMsg(msg);
}


















/*bool ElmoMotorCtrl::Watchdog(bool bBegin)
{
  if(bBegin==true)
  {

    const int c_iHeartbeatTimeMS = 1000;
    const int c_iNMTNodeID = 0x00;
    m_Watchdog=true;


    //heart beat consumer

    sendingSDODownload(0x1016, 1, (c_iNMTNodeID << 16) | c_iHeartbeatTimeMS);

    //error modes after failure : is 0=pre-operational, 1=no state change, 2=stopped
    sendingSDODownload(0x1029, 1, 2);

    //motor behaviour after heart beat failure : quick stopped
    sendingSDODownload(0x6007, 0, 3);

    //Object 0x2F21 = "Emergency Events" which cause an Emergency Message,,, Bit 3 is responsible for Heartbeart-Failure.--> Hex 0x08
     sendingSDODownload(0x2F21, 0, 0x08);
     usleep(20000);
  }

  else
  {
    m_Watchdog=false;
    //motor behaviour :no action
    sendingSDODownload(0x6007, 0, 0);

    //error state: no state change
    sendingSDODownload(0x1029, 1, 1);

    sendingSDODownload(0x2F21, 0, 0x00);
    usleep(24000);

  }
  return true;
}*/

