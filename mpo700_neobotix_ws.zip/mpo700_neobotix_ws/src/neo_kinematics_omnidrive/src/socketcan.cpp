
#include "ros/ros.h"
//-----------------------------------------------
#include <neo_kinematics_omnidrive/socketcan.h>
socketcan::socketcan()
{




	initsocket();
}

socketcan::~socketcan()
{


}
//-----------------------------------------------

//-----------------------------------------------
int socketcan::initsocket()
{

	if((s = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
		perror(" There is an error while opening socket");
		return -1;
	}

	strcpy(ifr.ifr_name, ifname);
	ioctl(s, SIOCGIFINDEX, &ifr);

	addr.can_family  = AF_CAN;
	addr.can_ifindex = ifr.ifr_ifindex;

	// printf("%s at index %d\n", ifname, ifr.ifr_ifindex);

	if(bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("Error in socket bind");
		return -2;
	}
	return 0;
}

//-------------------------------------------
void socketcan::transmitMsg(CanMesg CMsg){

	frame.can_id=CMsg.m_id;
	frame.can_dlc=CMsg.m_len;
	for(int i=0; i<8; i++)
		frame.data[i] = CMsg.getAt(i);

	nbytes = write(s, &frame, sizeof(struct can_frame));



}


//-------------------------------------------
void socketcan::receiveMsg(CanMesg* pCMsg)
{

	nbytes = read(s, &frame, sizeof(struct can_frame));
	pCMsg->m_id =frame.can_id;
	pCMsg->set(frame.data[0], frame.data[1], frame.data[2], frame.data[3],
			frame.data[4], frame.data[5], frame.data[6], frame.data[7]);






}
