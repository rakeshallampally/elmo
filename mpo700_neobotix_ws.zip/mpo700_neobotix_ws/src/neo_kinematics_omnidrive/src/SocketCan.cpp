
#include "ros/ros.h"
#include <neo_kinematics_omnidrive/SocketCan.h>

SocketCan::SocketCan()
{
	initsocket();
}

SocketCan::~SocketCan()
{

}

int SocketCan::initsocket()
{
	if((s = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) 
	{
		perror(" There is an error while opening socket");
		return -1;
	}

	strcpy(ifr.ifr_name, ifname);
	ioctl(s, SIOCGIFINDEX, &ifr);

	addr.can_family  = AF_CAN;
	addr.can_ifindex = ifr.ifr_ifindex;

	if(bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) 
	{
		perror("Error in socket bind");
		return -2;
	}

	return 0;
}


void SocketCan::transmitMsg(CanMesg CMsg)
{

    fd_set fds;
    struct timeval timeout = {0,10};
    int sel;
    FD_ZERO(&fds);
    FD_SET(s, &fds);
    sel = select(s+1, NULL, &fds, NULL, &timeout);
    if (sel<=0)
    {
	
	}
	else
	{
		frame.can_id=CMsg.m_id;
		frame.can_dlc=CMsg.m_len;

		for(int i=0; i<8; i++)
			frame.data[i] = CMsg.getByte(i);

		nbytes = write(s, &frame, sizeof(struct can_frame));

	}

}



bool SocketCan::receiveMsg(CanMesg* pCMsg)
{
	bool bret=false;
	int sel;
	struct timeval timeout = {0,10};
	fd_set readSet;
	FD_ZERO(&readSet);
	FD_SET(s, &readSet);

	sel=select((s+1 ), &readSet, NULL, NULL, &timeout);

	if (sel<=0)
    {
    	//ROS_INFO("Timedout while receiving message ");
    	pCMsg->m_id=0;
    	pCMsg->set(0, 0, 0, 0, 0, 0, 0, 0);
    			
    			

    }
	else
	{
		usleep(10000);
		nbytes = read(s, &frame, sizeof(struct can_frame));
		pCMsg->m_id =frame.can_id;
		pCMsg->set(frame.data[0], frame.data[1], frame.data[2], frame.data[3],frame.data[4], frame.data[5], frame.data[6], frame.data[7]);
		/*ROS_INFO("can_id: %X data length: %d data: ", frame.can_id,frame.can_dlc);

		for (int i = 0; i < frame.can_dlc; i++)
				ROS_INFO("%02X ", frame.data[i]);*/
			    bret=true;

    }

	return bret;
}










	
