
#include <neo_kinematics_omnidrive/Elmomotorctrl.h>
#include <unistd.h>

using namespace std;

Elmomotorctrl::Elmomotorctrl(){
  m_PositonGearMeasInRad=0;
  m_dAngleGearRadMem=0;
  m_baseInitialized=false;
  m_generalfailure=false;
  m_iStateOfMotor = STATE_PRE_INITIALIZED;
  m_bCurrentLimitOn == false;
  m_icount=0;
  iDivForRequestStatus=10;
}


void Elmomotorctrl::setCanOpenParam( int iTxPDO1, int iTxPDO2, int iRxPDO2, int iTxSDO, int iRxSDO)
{
  m_Paramcanopen.iTxPDO1 = iTxPDO1;
	m_Paramcanopen.iTxPDO2 = iTxPDO2;
	m_Paramcanopen.iRxPDO2 = iRxPDO2;
	m_Paramcanopen.iTxSDO = iTxSDO;
	m_Paramcanopen.iRxSDO = iRxSDO;

}



bool Elmomotorctrl::initializing()
{
  int iPositionCnt;
  bool bInitpos;
  int iMaxAcc = int(m_DriveParameter.getMaxAccln());
  int iMaxDcc = int(m_DriveParameter.getMaxDecln());
  int iCount,iPoscnt;
  bool bRet = true;
  CanMesg Msg;
// Set Values for Modulo-Counting. Neccessary to preserve absolute position for homed motors (after encoder overflow)
  int iIncrRevWheel = int( (double)m_DriveParameter.getGearratio() * (double)m_DriveParameter.getBeltRatio()
					* (double)m_DriveParameter.getEncoderIncrPerRevOfMot() * 3 );

//turn of motor
  Interprtset(8, 'M', 'O', 0, 0);
  usleep(20000);
// without this modulo chekcing we cannot turn on motor, so check modulo and its conditions
  Interprtset(8, 'X', 'M', 2, iIncrRevWheel * 5000);
  usleep(20000);
  Interprtset(8, 'X', 'M', 1, -iIncrRevWheel * 5000);
  usleep(20000);


//setting velocity as motion control( so as per manual following commands should be performed pg-77)
  Interprtset(8, 'M', 'O', 0, 0);

//switch to unit mode 2
  Interprtset(8, 'U', 'M', 0, 2);
// switch to profile mode 1(if unit mode 2)
  Interprtset(8, 'P', 'M', 0, 1);

// set maximum Acceleration to X Incr/s^2
  Interprtset(8, 'A', 'C', 0, iMaxAcc);
// set maximum decceleration to X Incr/s^2
  Interprtset(8, 'D', 'C', 0, iMaxDcc);
  usleep(100000);

//set position encounter to zero
  Interprtset(8, 'P', 'X', 0, 0);

  iCount=0;


  while (true)
    {
      if(Msg.getByte(0)=='P' && Msg.getByte(1)=='X')
        {
          iPositionCnt=(Msg.getByte(4))|(Msg.getByte(5)<<8)|(Msg.getByte(6)<<16)|(Msg.getByte(7)<<24);
          m_PositonGearMeasInRad=m_DriveParameter.getmotion_direction()*m_DriveParameter.PosMotIncrToPosGearRad(iPositionCnt);
          m_dAngleGearRadMem=m_PositonGearMeasInRad;
          break;
        }
      if (iCount>300)
        {
        cout<<"intial positon not set"<<endl;
        bInitpos =false;
        }
    usleep(1000);
    iCount++;
    }

// stop all emissions of TPDO1
  sendingSDOdownload(0x1A00, 0, 0);

// position 4 byte of TPDO1
  sendingSDOdownload(0x1A00, 1, 0x60640020);

// velocity 4 byte of TPDO1
  sendingSDOdownload(0x1A00, 2, 0x60690020);

// transmission type "synch"
  sendingSDOdownload(0x1800, 2, 1);

// activate mapped objects
  sendingSDOdownload(0x1A00, 0, 2);


  if(bInitpos)
		  m_baseInitialized = true;

  return bInitpos;


}



bool Elmomotorctrl::Homing()
{
  const int c_iPosReference = m_DriveParameter.getEncoderOffset();
  //disarm
  Interprtset(8, 'H', 'M', 1, 0);
  usleep(20000);
  //configure homing sequence
  Interprtset(8, 'H', 'M', 2,c_iPosReference);
  usleep(20000);

  Interprtset(8, 'H', 'M', 3,m_DriveParameter.getHomDigIn());
  usleep(20000);

  Interprtset(8, 'H', 'M', 4,2);
  usleep(20000);

  Interprtset(8, 'H', 'M',5,0);
  usleep(20000);

  return true;


}



bool Elmomotorctrl::Turningon()
{
  int iCount;
  Interprtset(8,'M','O',0,0);
  usleep(25000);
  bool bReturn;
  CanMesg Msg;
  int iStatus;


//sending request to evaluate status
  Interprtset(8,'S','R',0,0);
  iCount=0;

  while(true)
  {
    m_SockCan->receiveMsg(&Msg);
    if(Msg.getByte(0)=='S' && Msg.getByte(1)=='R')
      {
        iStatus=(Msg.getByte(4))|(Msg.getByte(5)<<8)|(Msg.getByte(6)<<16)|(Msg.getByte(7)<<24);
        breturn = evaluatestatus(iStatus);
      }
    else if(iCount>300)
      {
        cout<<"Elmomotorctrl:no answer on status request";
        breturn=false;
      }

  usleep(10000);
  iCount++;
  }

return breturn;
}



void Elmomotorctrl::SetGearVelinRads(double dGearvelrads)
  {
    int iVelEncIncrement;
  //calculating motor velocit from joint velocity
    iVelEncIncrement=m_DriveParameter.getmotion_direction()*m_DriveParameter.VelGearRadSToVelMotIncrPeriod(dGearvelrads);
    if(iVelEncIncrement>m_DriveParameter.getMaxVel())
      {
        iVelEncIncrement=(int)m_DriveParameter.getMaxVel();
      }
    else if(iVelEncIncrement<-m_DriveParameter.getMaxVel())
      {
        iVelEncIncrement=-(int)m_DriveParameter.getMaxVel();
      }

    Interprtset(8,'J','V',0,iVelEncIncrement);
    Interprtset(4,'B','G',0,0);
    CanMesg msg;
    msg.m_id  = 0x80;
    msg.m_len = 0;
    msg.set(0,0,0,0,0,0,0,0);
    m_SockCan->transmitMsg(msg);

//sending hearbeat
    msg.m_id  = 0x700;
    msg.m_len = 5;
    msg.set(0x00,0,0,0,0,0,0,0);
    m_SockCan->transmitMsg(msg);

    m_icount++;
    if(m_icount>iDivForRequestStatus)
      {
        Interprtset(4, 'S', 'R', 0, 0);
        m_icount=0;
      }
  }



bool Elmomotorctrl::evaluatestatus(int iStatus)
{
  bool berrorfree;
  if(isbitperfect(iStatus,6))
    {
      if(m_generalfailure=false)
        {
          cout<<"the following motor failure"<<m_DriveParameter.getIdentOfDrive()<<endl;
          Interprtset(4,'M','F',0,0);

        }
    m_modified_motor_state=STATE_MOTOR_FAILURE;
    berrorfree=false;
    }

  else if(isbitperfect(iStatus,0))
    {
      if(m_generalfailure=false)
        {
          if((0x0000000E & iStatus)==12)
          cout<<"oveheating error"<<endl;
          if((0x0000000E&iStatus)==10)
          cout<<"drive error short cirucit"<<endl;
          if((0x0000000E&iStatus)==4)
          cout<<"drive error over voltage"<<endl;
          if((0x0000000E&iStatus)==2)
          cout<<"drive error under voltage"<<endl;
          Interprtset(4,'M','F',0,0);
        }
      m_modified_motor_state=STATE_MOTOR_FAILURE;
      berrorfree=false;
    }

  else
    {
      berrorfree=true;
      m_generalfailure=false;
      if(isbitperfect(iStatus,4))
//motor on
        {
          if(m_iStateOfMotor != STATE_OPERATION_ENABLED)
            {
              cout<<"motor operation enabled for"<<m_DriveParameter.getIdentOfDrive();
            }
           m_modified_motor_state=STATE_OPERATION_ENABLED;
        }
  
      else
        {
          if(m_iStateOfMotor != STATE_OPERATION_DISABLED)
            {
              cout<<"motor operation disabled for"<<m_DriveParameter.getIdentOfDrive();
            }
        m_modified_motor_state=STATE_OPERATION_DISABLED;
        }

      if(isbitperfect(iStatus,13))
        {
          if (m_bCurrentLimitOn == false)
				  std::cout << "Motor current limit on" << m_DriveParameter.getIdentOfDrive() <<endl;
          m_bCurrentLimitOn = true;
		    }
	   else
		      m_bCurrentLimitOn = false;
    }

  m_iStateOfMotor=m_modified_motor_state;

  if(m_iStateOfMotor==STATE_MOTOR_FAILURE)
    m_generalfailure=true;
  
  return berrorfree;
}



bool Elmomotorctrl::Watchdog(bool bBegin)
{
  if(bBegin==true){

    const int c_iHeartbeatTimeMS = 1000;
		const int c_iNMTNodeID = 0x00;
    m_Watchdog=true;


    //heart beat consumer

    sendingSDOdownload(0x1016, 1, (c_iNMTNodeID << 16) | c_iHeartbeatTimeMS);

    //error modes after failure : is 0=pre-operational, 1=no state change, 2=stopped
    sendingSDOdownload(0x1029, 1, 2);

    //motor behaviour after heart beat failure : quick stopped
    sendingSDOdownload(0x6007, 0, 3);

    //Object 0x2F21 = "Emergency Events" which cause an Emergency Message,,, Bit 3 is responsible for Heartbeart-Failure.--> Hex 0x08
     sendingSDOdownload(0x2F21, 0, 0x08);
     usleep(20000);
  }

  else
  {
    m_Watchdog=false;
    //motor behaviour :no action
    sendingSDOdownload(0x6007, 0, 0);

    //error state: no state change
    sendingSDOdownload(0x1029, 1, 1);

    sendingSDOdownload(0x2F21, 0, 0x00);
    usleep(24000);

  }
  return true;
}






void Elmomotorctrl::sendingSDOdownload(int iIndex, int iSubindex, int iData)
{
  CanMesg msg;

  const int ciInitDownloadRequest = 0x20;//for bits 5,6,7 of byte 0  should have 001
	const int ciByteswithNoData = 0x00; //  for bits 2,3,4 should have 000
	const int ciExpedited = 0x02;//for bit 1 should have 1
	const int ciDataSizeIndicator = 0x01;//for bit 0 shoud have 1

  unsigned char cMesg[8];

  cMesg[0]=ciInitDownloadRequest|ciExpedited|ciDataSizeIndicator|(ciByteswithNoData<<2);
  cMesg[1]=iIndex;
  cMesg[2]=iIndex>>8;
  cMesg[3]=iSubindex;
  cMesg[4]=iData;
  cMesg[5]=iData>>8;
  cMesg[6]=iData>>16;
  cMesg[7]=iData>>24;

  msg.set(cMesg[0],cMesg[1],cMesg[2],cMesg[3],cMesg[4],cMesg[5],cMesg[6],cMesg[7]);
  m_SockCan->transmitMsg(msg);
}







void Elmomotorctrl::Interprtset(int iDatalen,char cmdchar1,char cmdchar2,int iIndex,int iData )
{
  char cIndex[2];
  char cInt[4];
  CanMesg Cmsg;
  Cmsg.m_id=m_Paramcanopen.iRxPDO2;
  Cmsg.m_len=iDatalen;

  cIndex[0]=iIndex;
  cIndex[1]=(iIndex >> 8) & 0x3F;

  cInt[0] = iData;
	cInt[1] = iData >> 8;
	cInt[2] = iData >> 16;
	cInt[3] = iData >> 24;


  Cmsg.set(cmdchar1,cmdchar2,cIndex[0],cIndex[1],cInt[0],cInt[1],cInt[2],cInt[3]);
 m_SockCan->transmitMsg(Cmsg);

}

bool Elmomotorctrl::stop()
{
  bool bret = true;
  Interprtset(8,'M','O',0,0);
  usleep(20000);
  return bret;
}


bool Elmomotorctrl::EvaluatingMessageReceived()
{

}
