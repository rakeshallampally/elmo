
#ifndef SOCKETCAN_INCLUDEDEF_H
#define SOCKETCAN_INCLUDEDEF_H
//-----------------------------------------------
#include <ros/ros.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>

#include <linux/can.h>
#include <linux/can/raw.h>
#include <neo_kinematics_omnidrive/CanMesg.h>
//-----------------------------------------------

class socketcan
{
public:


	ros::NodeHandle n;

	int s;
	int nbytes;
	struct sockaddr_can addr;
	struct can_frame frame;
	struct ifreq ifr;
	const char *ifname = "vcan0";
	// --------------- Interface
	socketcan();
	~socketcan();
	int initsocket();

	void transmitMsg(CanMesg CMsg);
	void receiveMsg(CanMesg* pCMsg);




};
//-----------------------------------------------
#endif
