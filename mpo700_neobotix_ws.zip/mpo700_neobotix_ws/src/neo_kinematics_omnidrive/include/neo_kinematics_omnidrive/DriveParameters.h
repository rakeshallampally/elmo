#ifndef DRIVEPARAMETERS_INCLUDEDEF_H
#define DRIVEPARAMETERS_INCLUDEDEF_H

class DriveParameters
{

private:

double    m_dAccIncrS2;
double    m_dDccIncrS2;
double    m_dgearratio;
double    m_dbeltratio;
int       m_iEncoderIncrPerRevOfmotor;
int       m_imotiondirection;//direction of motion
double    m_dVelMaxEncIncrS;
double    m_dPositionGearRadToPosMotIncr;
double    m_dVelMeasFrqHz;
int       m_iHomDigIn;
int       m_iIdentofdrive;
int       m_iEncOffsetIncrement;
bool      m_bIsSteer;
double    m_dCurrToTorque;
double    m_dCurrMax;

public:

double getMaxAccln()
{
	return m_dAccIncrS2;
}


double getMaxDecln()
{
	return m_dDccIncrS2;
}



double getGearratio()
{
	return m_dgearratio;
}


double getBeltRatio()
{
	return m_dbeltratio;
}


double getEncoderIncrPerRevOfMot()
{
	return m_iEncoderIncrPerRevOfmotor;
}


int getmotion_direction()
{
	return m_imotiondirection;
}


int convertVelGearRadSToVelMotIncrPeriod(double dGearvelrads)
{
	return ((int)(dGearvelrads * m_dPositionGearRadToPosMotIncr / m_dVelMeasFrqHz));
}


/*
 *converting enoder increments in to gear position in radians
 */
double convertPosMotIncrToPosGearRad(int iPositionCnt)
{
	return ((double)iPositionCnt / m_dPositionGearRadToPosMotIncr);
}


/*
 *conversion of encoder increments to gear vel in rad/s
 */
double convertVelMotIncrPeriodToVelGearRadS(int iVelMotIncrPeriod)
{
	return ((double)iVelMotIncrPeriod/  m_dPositionGearRadToPosMotIncr *m_dVelMeasFrqHz );
}



int getIdentOfDrive()
{
	return m_iIdentofdrive;
}


double getMaxVel()
{
	return m_dVelMaxEncIncrS;
}


int getEncoderOffset()
{
	return m_iEncOffsetIncrement;
}

//getting digital input for Homing
int getHomDigIn()
{
	return m_iHomDigIn;
}



void settingParams
        (
		int iDriveIdent,
		int iEncIncrPerRevMot,
		double dVelMeasFrqHz,
		double dBeltRatio,
		double dGearRatio,
		int iSign,
		double dVelMaxEncIncrS,
		double dAccIncrS2,
		double dDecIncrS2,
		int iEncOffsetIncr,
		bool bIsSteer,
        double dCurrToTorque,
		double dCurrMax,
		int iHomingDigIn
		)
{

		m_iIdentofdrive = iDriveIdent;
		m_iEncoderIncrPerRevOfmotor = iEncIncrPerRevMot;
		m_dVelMeasFrqHz = dVelMeasFrqHz;
		m_dbeltratio = dBeltRatio;
		m_dgearratio = dGearRatio;
		m_imotiondirection = iSign;
		m_dVelMaxEncIncrS = dVelMaxEncIncrS;
		m_dAccIncrS2 = dAccIncrS2;
		m_dDccIncrS2 = dDecIncrS2;
		m_iEncOffsetIncrement = iEncOffsetIncr;
		m_bIsSteer = bIsSteer;

		double dPI = 3.14159265358979323846;

		m_dPositionGearRadToPosMotIncr = m_iEncoderIncrPerRevOfmotor * m_dgearratio
			* m_dbeltratio / (2. * dPI);

        m_dCurrToTorque = dCurrToTorque;
		m_dCurrMax = dCurrMax;
		m_iHomDigIn = iHomingDigIn;
}




};


#endif
