#ifndef DRIVEPARAMETERS_INCLUDEDEF_H
#define DRIVEPARAMETERS_INCLUDEDEF_H

//-----------------------------------------------



class DriveParameters
{

private:

double m_dAccIncrS2;
double m_dDccIncrS2;
double m_dgearratio;
double m_dbeltratio;
int m_iEncoderIncrPerRevOfmotor;
int m_imotiondirection;//direction of motion
double m_dVelMaxEncIncrS;
double m_PositionGearRadToPosMotIncr;
double m_dVelMeasFrqHz;
int m_iHomDigIn;
int m_iIdentofdrive;
int m_iEncOffsetIncrement;
public:

double getMaxAccln()
{
	return m_dAccIncrS2;
}


double getMaxDecln()
{
return m_dDccIncrS2;
}



double getGearratio()
{
return m_dgearratio;
}


double getBeltRatio()
{
	return m_dbeltratio;
}


double getEncoderIncrPerRevOfMot(){
	return m_iEncoderIncrPerRevOfmotor;
}


int getmotion_direction()
{
	return m_imotiondirection;
}


int VelGearRadSToVelMotIncrPeriod(double dGearvelrads)
	{
		return ((int)(dGearvelrads * m_PositionGearRadToPosMotIncr / m_dVelMeasFrqHz));
	}

//converting enoder increments in to gear position
double PosMotIncrToPosGearRad(int iPositionCnt)
	{
		return ((double)iPositionCnt / m_PositionGearRadToPosMotIncr);
	}


int getIdentOfDrive()
	{
	  return m_iIdentofdrive;
	}


double getMaxVel()
		{
			return m_dVelMaxEncIncrS;
		}


int getEncoderOffset()
{
	return m_iEncOffsetIncrement;
}

//getting digital input for Homing
int getHomDigIn()
{
	return m_iHomDigIn;
}

};
//-----------------------------------------------
#endif
