#ifndef Elmomotorctrl_INCLUDEDEF_H
#define Elmomotorctrl_INCLUDEDEF_H

#include <neo_kinematics_omnidrive/CanMesg.h>
#include <neo_kinematics_omnidrive/DriveParameters.h>
#include <neo_kinematics_omnidrive/socketcan.h>

class Elmomotorctrl{
public:

//default constructor
Elmomotorctrl();


struct Paramcanopen{
    int iTxPDO1;
		int iTxPDO2;
		int iRxPDO2;
		int iTxSDO;
		int iRxSDO;
  };

void setCanOpenParam( int iTxPDO1, int iTxPDO2, int iRxPDO2, int iTxSDO, int iRxSDO);
void Interprtset(int iDatalen,char cmdchar1,char cmdchar2,int iIndex,int iData );
bool initializing();
bool stop();
void sendingSDOdownload(int iIndex, int iSubindex, int iData);
bool Watchdog(bool bBegin);
bool Turningon();

bool evaluatestatus(int iStatus);
void SetGearVelinRads(double dGearvelrads);
//states of drive
enum drivestates
  {
    STATE_PRE_INITIALIZED,
    STATE_OPERATION_ENABLED,
    STATE_OPERATION_DISABLED,
    STATE_MOTOR_FAILURE
  };

bool isbitperfect(int iValue, int iBit){
   if((iValue & (1<<iBit))!=0)
    return true;
  else
    return false;
  }


bool Homing();



protected:
Paramcanopen m_Paramcanopen;
DriveParameters m_DriveParameter;

//objects for classes
socketcan* m_SockCan;

double m_PositonGearMeasInRad;
double m_dAngleGearRadMem;
bool m_baseInitialized;
bool m_Watchdog;
bool m_generalfailure;
int m_iStateOfMotor;
int m_modified_motor_state;
bool m_bCurrentLimitOn;
int iDivForRequestStatus;
int m_icount;
};
#endif
