
#ifndef SOCKETCAN_INCLUDEDEF_H
#define SOCKETCAN_INCLUDEDEF_H

#include <ros/ros.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <fcntl.h>

#include <linux/can.h>
#include <linux/can/raw.h>
#include <neo_kinematics_omnidrive/CanMesg.h>



class SocketCan
{
public:

	int s;
	int nbytes,t;
	struct sockaddr_can addr;
	struct can_frame frame;
	struct ifreq ifr;
	const char *ifname = "can0";
	SocketCan();
	~SocketCan();
	int initsocket();
	void transmitMsg(CanMesg CMsg);
	bool receiveMsg(CanMesg* pCMsg);

};

#endif
