#ifndef NEOOMNIDRIVEERRORS_INCLUDEDEF_H
#define NEOOMNIDRIVEERRORS_INCLUDEDEF_H


/*
 * struct which stores all the errors 
 */

struct DriveErrors
{
  int iNoError=0;                                     // No error             
  int iInitPosNotSet=1;                               // Intitial positon is not set
  int iHomingfailed=2;                                // Homing failed                       
  int iStatusReqFail=3;                               // No answer on status request
  int iMotorFailure=4;                                // Motor failure lathced
  int iOverHeating=5;                                 // Over heating
  int iShortCircuit=6;                                // Drive error short cirucit
  int iOverVoltage=7;                                 // Drive error over voltage 
  int iUnderVoltage=8;                                // Drive error under voltage
  int iMotorOff=9;                                    // Motor is still Off
  int iCurrentLimintOn=10;                            // Motor current limit on
  int iFeedbackLoss=11;                               // feedback loss
  int iPeakCurrentExced=12;                           // Peak current excced
  int iSpeedTrack=13;                                 // Speed track error
  int iPositionTrack=14;                              // position track error
  int iSpeedLimit=15;                                 // speed limit exceeded
  int iMotorStuck=16;                                 // motor stuck

};


//declaring objects for the motor params struct
DriveErrors m_DriveError;


#endif
